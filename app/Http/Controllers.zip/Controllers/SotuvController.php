<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SotuvController extends Controller
{
           public function index()
            {   

              $users = DB::table('sotuv')->select("id","cashback", "jami","usta_id", "filial_id", "data", "time_create")->orderBy("id", "desc")->get();
              return $users;
            }



    public function create(Request $request) {
        
        $usta_id = $request->json()->get("usta_id");
        $filial_id = $request->json()->get("filial_id");
        $id = $request->json()->get("id");
        $data = $request->json()->all();
        $bonus = $request->json()->get("cashback");
        $jami = $request->json()->get("jami");
        $holat = $request->json()->get("holat");
        $k = 0 ;
        if ( $holat == 1) {
          $k = 2;
        }

        DB::table("bonus")->upsert(["id"=>$id, "bonus"=> $bonus, "kirimChiqim"=> $k, "usta_id"=> $usta_id],["id"]);


        $affected = DB::table('sotuv')->upsert(["id"=> $id, "jami"=> $jami, "cashback"=> $bonus,"usta_id"=> $usta_id,"holat"=> $holat, "filial_id"=> $filial_id, "data"=> json_encode($data)],['id']);
        return $affected;
    }


     public function bonuslar() {
        $users = DB::select("SELECT * FROM ( SELECT usta_id as id,SUM(CASE WHEN kirimChiqim = 0 THEN (bonus.bonus * 1) ELSE (bonus.bonus * -1) END) as bonus, ustalar.fam_ism, ustalar.telefon FROM bonus LEFT JOIN ustalar ON bonus.usta_id= ustalar.id GROUP BY usta_id ) as ost WHERE ost.bonus > 0
");

        return $users;
     }


     public function hisoblashish(Request $request) {

          $id = $request->json()->get("id");
          $bonus = $request->json()->get("bonus");
          $usta_id = $request->json()->get("usta_id");
         $affected =  DB::table("bonus")->insert(["id"=> $id, "bonus"=> $bonus, "usta_id"=> $usta_id, "kirimChiqim"=> "1"]);

         return $affected;
     }

     public function delete(Request $request, $id) {

            DB::table("bonus")->where("id", "=", $id)->delete();
           $affected =  DB::table("sotuv")->where("id", "=", $id)->delete();
           return $affected;
     }

}
