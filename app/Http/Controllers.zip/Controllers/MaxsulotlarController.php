<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class MaxsulotlarController extends Controller
{
           public function index()
            {   

              $users = DB::table('maxsulotlar')->select("id", "nomi", "narxi", "bonus", "brend_id", "olchov_id", "tur_id")->orderBy("id", "desc")->get();
              return $users;
            }


public function create(Request $request) {
      $data = $request->json()->all();
        $id = $request->json()->get("id");

        $affected = DB::table('maxsulotlar')->upsert($data,['id']);
        return $affected;
    }   
        
   




    public function delete(Request $request, $id) {

      $affected = DB::table("maxsulotlar")->where("id", "=", $id)->delete();
        return $affected;
    }

    public function alldata() { 
        $brend = DB::table('brend')->select("id", "nomi")->orderBy("id", "desc")->get();

        $tur = DB::table('maxsulotturi')->select("id", "nomi")->orderBy("id", "desc")->get();

        $olchov = DB::table('olchov')->select("id", "nomi")->orderBy("id", "desc")->get();


        $data = ["brend"=> $brend, "tur"=> $tur, "olchov"=> $olchov];
        return $data;

    }


     public function secdata() { 
        $filial = DB::table('filiallar')->select("id", "nomi")->orderBy("id", "desc")->get();

        $ustalar = DB::table('ustalar')->select("id", "fam_ism")->orderBy("id", "desc")->get();



        $data = ["filial"=> $filial, "ustalar"=> $ustalar];
        return $data;

    }



    public function filialmaxs() {
        $users = DB::select("SELECT maxsulotlar.id, maxsulotlar.nomi, maxsulotlar.narxi, maxsulotlar.bonus, brend.nomi as brend_nomi, olchov.nomi as olchov_nomi, maxsulotturi.nomi as max_turi FROM `maxsulotlar` LEFT JOIN brend ON maxsulotlar.brend_id = brend.id LEFT JOIN olchov ON maxsulotlar.olchov_id = olchov.id LEFT JOIN maxsulotturi ON maxsulotlar.tur_id = maxsulotturi.id");
        return $users;
    }
}
