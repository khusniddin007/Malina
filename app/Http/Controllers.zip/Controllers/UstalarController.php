<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UstalarController extends Controller
{
           public function index()
            {   

              $users = DB::table('ustalar')->select("id", "fam_ism", "telefon", "telefon_2", "vil_id", "manzil", "birth", "parol", "img")->orderBy("id", "desc")->get();
              return $users;
            }



    public function create(Request $request) {
        
        $data = $request->json()->all();
        $id = $request->json()->get("id");

        $affected = DB::table('ustalar')->upsert($data,['id']);
        return $affected;
    }




    public function delete(Request $request, $id) {

      $affected = DB::table("ustalar")->where("id", "=", $id)->delete();
        return $affected;
    }


     public function loginusta(Request $request)
            {   
              $telefon = $request->input('telefon');
              $parol = $request->input('parol');

              $users = DB::table('ustalar')
            ->select('id', "fam_ism", "telefon", "img")->where('telefon', '=', $telefon)->where('parol', '=', $parol)
            ->get();

            return $users;
    }
    public function cashback(Request $request, $id) {
        $affected = DB::select("SELECT SUM(CASE WHEN kirimChiqim = 0 THEN (bonus.bonus * 1) ELSE (bonus.bonus * -1) END) as bonus FROM bonus WHERE usta_id = ? GROUP BY usta_id", [$id]);

        return $affected;
    }
    public function telcheck(Request $request, $tel) {
        $affected = DB::select("SELECT telefon FROM ustalar where telefon = ?", [$tel]);

        return $affected;
    } 


    public function ustabonus (Request $request, $id) {
          $affected = DB::select(" SELECT bonus.kirimChiqim,bonus.time_create,bonus.bonus, ustalar.fam_ism, ustalar.telefon FROM bonus LEFT JOIN ustalar ON bonus.usta_id= ustalar.id WHERE bonus.usta_id = ? ORDER BY bonus.time_create DESC", [$id]);
          return $affected;
    }



    public function photo(Request $request, $id) {

            $ext = $request->file('avatar')->getClientOriginalExtension();
            $name = md5(time()).".".$ext;
            $file = $request->file('avatar')->move("./storage", $name);

            $user = DB::table("ustalar")->select("img")->where("id", $id)->get();

            $link = null;
            foreach ($user as $one) {
              $link = $one->img;
            }

            if ($link) {
               unlink($link);
            }

            DB::table("ustalar")->where("id", $id)->update(["img"=> $file]);
            return $file;
    }


}
