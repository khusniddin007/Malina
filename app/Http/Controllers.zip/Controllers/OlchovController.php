<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OlchovController extends Controller
{
           public function index()
            {   

              $users = DB::table('olchov')->select("id", "nomi")->orderBy("id", "desc")->get();
              return $users;
            }



    public function create(Request $request) {
        
        $data = $request->json()->all();
        $id = $request->json()->get("id");

        $affected = DB::table('olchov')->upsert($data,['id']);
        return $affected;
    }




    public function delete(Request $request, $id) {

      $affected = DB::table("olchov")->where("id", "=", $id)->delete();
        return $affected;
    }
}
